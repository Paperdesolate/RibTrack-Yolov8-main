def readtxt(file_path):
    def read_txt_file(file_path):
        try:
            with open(file_path, 'r') as file:
                content = file.readlines()
            return content
        except FileNotFoundError:
            return None
        except Exception as e:
            return None

    def get_columns_2_3_4(content):
        if content is None:
            return None
        try:
            data = []
            for line in content:
                line = line.strip().split()
                column_2_3_4 = [float(line[1]), float(line[2]), int(line[3])]
                data.append(column_2_3_4)
            return data
        except Exception as e:
            return None

    # # 指定文件路径
    # file_path = "D:/rib_gui2/runs/detect/Rib/L5.txt"

    # 读取文件内容
    file_content = read_txt_file(file_path)

    # 获取每一行的第2、3、4列数据
    if file_content is not None:
        extracted_data = get_columns_2_3_4(file_content)
    #     if extracted_data is not None:
    #         print(extracted_data)
    #     else:
    #         print("Failed to extract data from file content.")
    # else:
    #     print("Failed to read file content.")

    return extracted_data