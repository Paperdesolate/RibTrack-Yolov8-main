import SimpleITK as sitk
import vtkmodules.all as vtk
from gettxt import readtxt
import os

def tangentspace(folder_path,rib_num):
    #获取图片与dcm文件之间的对应关系
    def getspacing(folder_path):
        # 读取DICOM序列
        reader = sitk.ImageSeriesReader()
        dicom_names = reader.GetGDCMSeriesFileNames(folder_path)
        reader.SetFileNames(dicom_names)
        image = reader.Execute()

        # 获取像素间距和层间距
        spacing = image.GetSpacing()  # 返回一个元组，(像素宽度, 像素高度, 层间距)
        return spacing

    spacing=getspacing(folder_path)
    # print(spacing[0])


    #进行vtk重建
    reader = vtk.vtkDICOMImageReader()
    reader.SetDirectoryName(folder_path)
    reader.Update()

    a=readtxt(file_path = 'D:/rib_gui2/runs/detect/Rib/' + rib_num + '.txt')

    # 计算文件夹中.dcm文件的数量
    dcm_number = sum(1 for file in os.listdir(folder_path) if file.endswith('.dcm'))
    p1 = [(a[0][0])*spacing[0],(512-a[0][1])*spacing[1],(dcm_number-a[0][2])*spacing[2]]  # 第一个点坐标
    p2 = [(a[1][0])*spacing[0], (512-a[1][1])*spacing[1],	(dcm_number-a[1][2])*spacing[2]]  # 第二个点坐标
    p3 = [(a[2][0])*spacing[0]	,(512-a[2][1])*spacing[1],	(dcm_number-a[2][2])*spacing[2]]# 第三个点坐标



    # 计算并设置平面的法线向量
    edge1 = [p2[i] - p1[i] for i in range(3)]
    edge2 = [p3[i] - p1[i] for i in range(3)]
    normal = [edge1[1] * edge2[2] - edge1[2] * edge2[1],
            edge1[2] * edge2[0] - edge1[0] * edge2[2],
            edge1[0] * edge2[1] - edge1[1] * edge2[0]]
    plane = vtk.vtkPlane()
    plane.SetOrigin(p1)  # 设置初始位置为第一个点
    cut = vtk.vtkCutter()

    global pp
    pp = p1

    # 创建骨窗函数
    window_level = -100  # 选择合适的窗位和窗宽
    window_width = 1800

    bone_window = vtk.vtkImageMapToWindowLevelColors()
    bone_window.SetInputConnection(reader.GetOutputPort())
    bone_window.SetWindow(window_width)
    bone_window.SetLevel(window_level)

    value_range = reader.GetOutput().GetScalarRange()
    m_pShift = vtk.vtkImageShiftScale()
    m_pShift.SetShift(-1.0*value_range[0])
    m_pShift.SetScale(255.0/(value_range[1] - value_range[0]))
    m_pShift.SetOutputScalarTypeToUnsignedChar()
    m_pShift.SetInputConnection(reader.GetOutputPort())
    m_pShift.Update()

    # 创建图像切片视图器
    mapper = vtk.vtkPolyDataMapper()
    mapper.SetInputConnection(cut.GetOutputPort())
    actor = vtk.vtkActor()
    actor.SetMapper(mapper)
    renderer = vtk.vtkRenderer()
    renderer.AddActor(actor)
    renderWindow = vtk.vtkRenderWindow()
    renderWindow.SetSize(1400, 1000) 
    renderWindow.AddRenderer(renderer)
    def updatacutdata(p):
        plane.SetNormal(normal)
        cut.SetCutFunction(plane)  # 指定沿plane进行切面
        cut.SetInputConnection(bone_window.GetOutputPort())
        plane.SetOrigin(p)
        cut.Update()
        renderWindow.Render()
    updatacutdata(p1)
    def on_mousewheel1(obj, event):
        pp[2]= pp[2]+1
        updatacutdata(pp)

    def on_mousewheel2(obj, event):
        pp[2]= pp[2]-1
        updatacutdata(pp)

    interactor = vtk.vtkRenderWindowInteractor()
    interactor.SetRenderWindow(renderWindow)
    interactor.RemoveAllObservers()
    interactor.AddObserver("MouseWheelForwardEvent", on_mousewheel1)
    interactor.AddObserver("MouseWheelBackwardEvent", on_mousewheel2)

    interactor.Initialize()
    renderWindow.Render()
    interactor.Start()

    return renderer, interactor

# tangentspace("D:/CT/200242122 (2)/a39",'L5')