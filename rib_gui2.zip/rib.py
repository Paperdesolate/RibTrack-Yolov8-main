from PySide6.QtWidgets import QApplication,QWidget,QPushButton,QLabel,QVBoxLayout,QLineEdit,QSlider,QFileDialog,QComboBox,QProgressBar
from PySide6.QtCore import Qt,QTimer,QThread, Signal,QDir
from PIL import Image,ImageFilter,ImageQt
from PySide6.QtGui import QPixmap
from qt_material import apply_stylesheet
from ultralytics import YOLO
import matplotlib.pyplot as plt
import numpy as np
import csv
import os
from B直接出图 import run
from 肋骨_ui import Ui_Form
from tangent_space import tangentspace

class Worker(QThread):
    progress_changed = Signal(int)

    def __init__(self, directory):
        super().__init__()
        self.directory = directory

    def run(self):
        total_files = len(QDir(self.directory).entryList())
        loaded_files = 0
        for i in range(total_files):
            # Simulate loading files
            loaded_files += 1
            progress = int(loaded_files / total_files * 100)
            self.progress_changed.emit(progress)


class MyWindow(QWidget,Ui_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.initUI()

    def initUI(self):
        self.setWindowTitle("打开文件夹示例")

        # 创建按钮和下拉框
        self.pushButton.clicked.connect(self.openFolder)
        # self.pushButton_2.clicked.connect(self.openFolder2)
        self.pushButton_2.clicked.connect(self.visiualspace)

        self.comboBox.addItems(["L1", "L2",'L3','L4','L5','L6','L7','L8','L9','L10','L11','L12',
                                'R1','R2','R3','R4','R5','R6',"R7","R8",'R9','R10','R11','R12'])  # 添加下拉框选项
        
        self.comboBox.currentIndexChanged.connect(self.update_image)  # 绑定下拉框选项改变的事件

        #创建进度条
        self.progressBar.setTextVisible(True)  # 显示进度条文本

        # 创建显示图片的标签
        self.label_2.setAlignment(Qt.AlignCenter)
        self.label_4.setAlignment(Qt.AlignCenter)
        self.label_5.setAlignment(Qt.AlignCenter)
        #显示图片1
        def display_image2(image_path):
            self.image_path = image_path
            pixmap = QPixmap(image_path)
            self.label_4.setPixmap(pixmap.scaledToWidth(300))  # 缩放图片以适应标签宽度

        display_image2('./runs/zy.png')
        #显示图片2
        def display_image3(image_path):
            self.image_path = image_path
            pixmap = QPixmap(image_path)
            self.label_5.setPixmap(pixmap.scaledToWidth(2000))  # 缩放图片以适应标签宽度

        display_image3('./runs/1.png')

        #时间控制器
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_progress)
        self.timer_interval = 2100  # milliseconds
        self.total_progress = 0
        self.total_time = 194000

        # 创建滑动条
        self.slider.setMinimum(1)
        self.slider.setMaximum(200)
        self.slider.setValue(100)
        self.slider.setTickInterval(10)
        self.slider.setTickPosition(QSlider.TicksBelow)
        self.slider.valueChanged.connect(self.update_image_scale)

        #控件美化
        self.label.setStyleSheet('background-color: rgb(255, 255, 255);border-radius: 10px; border: 3px groove green;border-style: outset;font-size: 20px;')
        self.label_2.setStyleSheet('background-color: rgb(255, 255, 255);border-radius: 10px; border: 5px groove green;border-style: outset;font-size: 20px;')
        self.label_3.setStyleSheet('background-color: rgb(255, 255, 255);border-radius: 10px; border: 3px groove green;border-style: outset;font-size: 20px;')

    def openFolder(self):
        self.folder_path = QFileDialog.getExistingDirectory(self, "选择文件夹", ".")
        save_path = 'D:/rib_gui2/runs/detect/Rib'
        # if self.folder_path:
        #     self.load_folder(self.folder_path)
        # self.start_slow_progress
        # self.timer = QTimer(self)
        # self.timer.timeout.connect(self.update_progress)

        import pydicom
        import cv2
        import SimpleITK as sitk
        import numpy as np
        import random
        from ultralytics import YOLO
        import shutil
        import vtkmodules.all as vtk
        import os
        import math
        from moviepy.editor import VideoFileClip
        import re
        import time

        # 读取dicom文件夹并自动调整窗宽窗位
        def translate(folder_path):
            reader = sitk.ImageSeriesReader()  # sitk读取dicom图像类
            image_path = reader.GetGDCMSeriesFileNames(folder_path)  # 获取文件夹内所有切片路径
            reader.SetFileNames(image_path)  # 通过上面获取到的路径来读取每一张dcm图片
            ds = pydicom.dcmread(image_path[0])
            slope = ds.RescaleSlope
            intercept = ds.RescaleIntercept
            image = reader.Execute()  # 得到对应的3D图像
            img = image[0]
            min_value = np.min(img)
            image_array = sitk.GetArrayFromImage(image)  # 把sitk读取到的dicom文件转为np数组
            hu_data = image_array * slope + intercept
            WW2 = 900  # ww1800
            if min_value == -2048:
                WL = -100  # -1000或-100
            else:
                WL = -1000  # -1000或-100
            WW = WW2 * 2
            High = WL + WW2
            Low = WL - WW2
            hu_data = np.clip(hu_data, Low, High)  # 将数据类型转换为uint8，并将其范围缩放到0-255
            hu_data = ((((hu_data) - Low) / WW) * 255).astype(np.uint8)
            arr_4d = np.repeat(hu_data[:, :, :, np.newaxis], 3, axis=3)
            return arr_4d

        # 转化为mp4格式
        def numpy_array_to_video(numpy_array, video_out_path):
            video_height = numpy_array.shape[1]
            video_width = numpy_array.shape[2]
            out_video_size = (video_width, video_height)
            output_video_fourcc = int(cv2.VideoWriter_fourcc(*'avc1'))
            video_write_capture = cv2.VideoWriter(video_out_path, output_video_fourcc, 30, out_video_size)
            for frame in numpy_array:
                video_write_capture.write(frame)
            video_write_capture.release()

        import os
        for filename in os.listdir(save_path):
            file_path = os.path.join(save_path, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)  # 删除文件或链接
                elif os.path.isdir(file_path):
                    continue  # 删除文件夹
            except Exception as e:
                print('Failed to delete %s. Reason: %s' % (file_path, e))

        translated_array = translate(self.folder_path)
        video_out_path = save_path + "/" + "Rib.mp4"
        numpy_array_to_video(translated_array, video_out_path)

        # 切分保存视频
        def split_video(video_path):
            # 加载视频文件
            clip = VideoFileClip(video_path)
            # 获取视频的宽度和高度
            width, height = clip.size
            # 计算新的宽度（这里是将宽度分为两半）
            new_width = width // 2
            # 裁剪左半部分
            left_clip = clip.crop(x1=0, y1=0, x2=new_width, y2=height)
            left_clip.write_videofile(save_path + "/" + "Rib_Right.mp4")
            # 裁剪右半部分
            right_clip = clip.crop(x1=new_width, y1=0, x2=width, y2=height)
            right_clip.write_videofile(save_path + "/" + "Rib_Left.mp4")

        split_video(video_out_path)

        #===========================================================================================

        # 设置深度学习的txt文件的路径
        mergefiledir_left = save_path + '/' + 'Rib_Left/labels'
        mergefiledir_right = save_path + '/' + 'Rib_Right/labels'
        final_file_path_left = save_path + '/Rib_Left/' + 'L.txt'
        final_file_path_right = save_path + '/Rib_Right/' + 'R.txt'

        # 清空文件夹内容，确保下次正确运行
        for filename in os.listdir(mergefiledir_left):
            file_path = os.path.join(mergefiledir_left, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)  # 删除文件或链接
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)  # 删除文件夹
            except Exception as e:
                print('Failed to delete %s. Reason: %s' % (file_path, e))

        for filename in os.listdir(mergefiledir_right):
            file_path = os.path.join(mergefiledir_right, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)  # 删除文件或链接
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)  # 删除文件夹
            except Exception as e:
                print('Failed to delete %s. Reason: %s' % (file_path, e))


        # 目标检测和跟踪
        Model = YOLO("D:/rib_gui2/runs/detect/train11/weights/best.pt")
        Model.track(source=save_path + "/" + "Rib_Right.mp4", show=True,save=True, save_txt=True, imgsz=512, save_conf=True,tracker="bytetrack.yaml",name=save_path + '/Rib_Right')
        Model.track(source=save_path + "/" + "Rib_Left.mp4", show=True,save=True, save_txt=True, imgsz=512, save_conf=True,tracker="bytetrack.yaml",name=save_path + '/Rib_Left')

        #=============================================================================================================

        # 初始化存储行的字典
        lines_by_number1 = {i: [] for i in range(1, 31)}
        lines_by_number2 = {i: [] for i in range(1, 31)}

        with open(final_file_path_left, 'w', encoding='utf8') as final_file1:
            filenames1 = os.listdir(mergefiledir_left)
            for filename in filenames1:
                file_number1 = filename.split('_')[-1].split('.')[0]
                filepath1 = os.path.join(mergefiledir_left, filename)
                with open(filepath1, encoding='utf8') as file1:
                    for line in file1:
                        parts1 = line.strip().split(" ")
                        parts1[0] = '0'
                        del parts1[3:6]
                        parts1[1] = str(float(parts1[1]) * 256+256)
                        parts1[2] = str(float(parts1[2]) * 512)
                        parts1.insert(-1, file_number1)
                        new_line1 = " ".join(parts1)
                        final_file1.write(new_line1 + '\n')
                        last_number1 = float(parts1[-1])
                        if last_number1 in lines_by_number1:
                            lines_by_number1[last_number1].append((float(file_number1), new_line1))

        with open(final_file_path_right, 'w', encoding='utf8') as final_file2:
            filenames2 = os.listdir(mergefiledir_right)
            for filename in filenames2:
                file_number2 = filename.split('_')[-1].split('.')[0]
                filepath2 = os.path.join(mergefiledir_right, filename)
                with open(filepath2, encoding='utf8') as file2:
                    for line in file2:
                        parts2 = line.strip().split(" ")
                        parts2[0] = '1'
                        del parts2[3:6]
                        parts2[1] = str(float(parts2[1]) * 256)
                        parts2[2] = str(float(parts2[2]) * 512)
                        parts2.insert(-1, file_number2)
                        new_line2 = " ".join(parts2)
                        final_file2.write(new_line2 + '\n')
                        last_number2 = float(parts2[-1])
                        if last_number2 in lines_by_number2:
                            lines_by_number2[last_number2].append((float(file_number2), new_line2))


        def write_lines_to_files_sorted_and_filtered1(lines_dict):
            for number, lines in lines_dict.items():
                file_path = os.path.join(save_path, f'L{number}.txt')
                sorted_lines = sorted(lines, key=lambda x: x[0])
                # 检查行数是否小于等于5
                if len(sorted_lines) <= 12:
                    continue
                else:
                    # 舍弃多余的行，使其行数为五的倍数
                    lines_to_keep_count = len(sorted_lines) - len(sorted_lines) % 5
                    sorted_lines = sorted_lines[:lines_to_keep_count]
                    # 五等分并从第一、第三、第五份中各随机抽取一行
                    parts = [sorted_lines[i:i + lines_to_keep_count // 5] for i in
                            range(0, lines_to_keep_count, lines_to_keep_count // 5)]
                    selected_lines = [random.choice(part)[1] for part in parts[1:4]]  # 修改为选取第二、第三、第四份

                with open(file_path, 'w', encoding='utf8') as file:
                    for line in selected_lines:
                        file.write(line + '\n')

        def write_lines_to_files_sorted_and_filtered2(lines_dict):
            for number, lines in lines_dict.items():
                file_path = os.path.join(save_path, f'R{number}.txt')
                sorted_lines = sorted(lines, key=lambda x: x[0])
                # 检查行数是否小于等于5
                if len(sorted_lines) <= 12:
                    continue
                else:
                    # 舍弃多余的行，使其行数为五的倍数
                    lines_to_keep_count = len(sorted_lines) - len(sorted_lines) % 5
                    sorted_lines = sorted_lines[:lines_to_keep_count]
                    # 五等分并从第一、第三、第五份中各随机抽取一行
                    parts = [sorted_lines[i:i + lines_to_keep_count // 5] for i in
                            range(0, lines_to_keep_count, lines_to_keep_count // 5)]
                    selected_lines = [random.choice(part)[1] for part in parts[1:4]]  # 修改为选取第二、第三、第四份

                with open(file_path, 'w', encoding='utf8') as file:
                    for line in selected_lines:
                        file.write(line + '\n')

        write_lines_to_files_sorted_and_filtered1(lines_by_number1)
        write_lines_to_files_sorted_and_filtered2(lines_by_number2)

        # 重命名文件
        def rename_files(save_path, prefix):
            # 获取所有特定前缀的文件并过滤出格式为txt的文件
            files = [f for f in os.listdir(save_path) if re.match(rf'{prefix}\d+\.txt', f)]

            # 提取文件名中的数字并排序
            sorted_files = sorted(files, key=lambda x: int(re.search(r'\d+', x).group()))

            # 第一步：临时重命名所有文件，使用临时前缀避免命名冲突
            temp_prefix = "temp_"
            for file in sorted_files:
                os.rename(os.path.join(save_path, file), os.path.join(save_path, temp_prefix + file))

            # 第二步：从临时命名的文件中按照倒序编号逻辑进行最终重命名
            start_number = 12
            for file in sorted_files:
                new_name = f"{prefix}{start_number}.txt"
                os.rename(os.path.join(save_path, temp_prefix + file), os.path.join(save_path, new_name))
                start_number -= 1

        # 分别对L开头和R开头的文件进行重命名
        rename_files(save_path, 'L')
        rename_files(save_path, 'R')


        # ========================================================================================================================
        import os
        import math
        import time

        def read_files_and_store_values(directory, prefix):
            results = {}
            for file_name in os.listdir(directory):
                if file_name.startswith(prefix) and file_name.endswith('.txt'):
                    file_path = os.path.join(directory, file_name)
                    with open(file_path, 'r') as file:
                        first_line = file.readline().strip()
                        last_value = first_line.split()[-1]
                        if len(results) < 20:
                            results[file_name] = last_value
            return results

        def find_extremes_and_write(results, labels_path, output_max_path, output_min_path):
            with open(output_max_path, 'w') as max_file, open(output_min_path, 'w') as min_file:
                for key in results:
                    target_value = results[key]
                    max_value = -float('inf')
                    min_value = float('inf')
                    max_line = None
                    min_line = None
                    with open(labels_path, 'r') as file:
                        for line in file:
                            parts = line.strip().split()
                            if parts[-1] == target_value:
                                second_last_value = float(parts[-2])
                                if second_last_value > max_value:
                                    max_value = second_last_value
                                    max_line = line.strip()
                                if second_last_value < min_value:
                                    min_value = second_last_value
                                    min_line = line.strip()
                    if max_line:
                        max_file.write(max_line + '\n')
                    if min_line:
                        min_file.write(min_line + '\n')

        def calculate_distance(x1, y1, x2, y2):
            return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

        def read_points_from_file(file_path):
            points = []
            with open(file_path, 'r') as file:
                for line in file:
                    parts = line.strip().split()
                    x = float(parts[1])
                    y = float(parts[2])
                    points.append((x, y, line.strip()))
            return points

        def compare_points_and_write(start_path, finish_path, output_path):
            start_points = read_points_from_file(start_path)
            finish_points = read_points_from_file(finish_path)
            with open(output_path, 'w') as output_file:
                for x1, y1, full_line in start_points:
                    for x2, y2, _ in finish_points:
                        if calculate_distance(x1, y1, x2, y2) < 5:
                            last_value = full_line.split()[-1]
                            output_file.write(f"{last_value}\n")
                            break

        def read_target_numbers(file_path):
            numbers = set()
            with open(file_path, 'r') as file:
                for line in file:
                    number = line.strip()
                    numbers.add(number)
            return numbers

        def delete_target_files(directory_path, target_numbers,prefix):
            for file_name in os.listdir(directory_path):
                if file_name.startswith(prefix) and file_name.endswith('.txt'):
                    file_path = os.path.join(directory_path, file_name)
                    try:
                        with open(file_path, 'r') as file:
                            first_line = file.readline().strip()
                            last_number = first_line.split()[-1]
                        # 显示地关闭文件，虽然with应该处理了这一步
                        file.close()  # 显式关闭文件（通常是多余的）
                        if last_number in target_numbers:
                            time.sleep(1)  # 延迟1秒，等待系统释放文件
                            os.remove(file_path)
                    except Exception as e:
                        print(f"Failed to delete {file_name}: {str(e)}")

        def process_files(prefix):
            directory_path = 'D:/rib_gui2/runs/detect/Rib'

            # 根据前缀决定左侧或右侧路径
            side = "Left" if prefix == 'L' else "Right"
            labels_path = f'D:/rib_gui2/runs/detect/Rib/Rib_{side}/{prefix}.txt'

            output_max_path = f'D:/rib_gui2/{prefix}finish.txt'
            output_min_path = f'D:/rib_gui2/{prefix}start.txt'
            output_path = f'D:/rib_gui2/{prefix}close_points.txt'

            values_dict = read_files_and_store_values(directory_path, prefix)
            find_extremes_and_write(values_dict, labels_path, output_max_path, output_min_path)
            compare_points_and_write(output_min_path, output_max_path, output_path)
            close_points_path = output_path
            target_numbers = read_target_numbers(close_points_path)
            delete_target_files(directory_path, target_numbers,prefix)

        process_files('L')
        process_files('R')

        # ===========================================================================================


        import SimpleITK as sitk
        import numpy as np
        import vtkmodules.all as vtk
        import os
        import re

        def rename_files(save_path, prefix):
            # 获取所有特定前缀的文件并过滤出格式为txt的文件
            files = [f for f in os.listdir(save_path) if re.match(rf'{prefix}-?\d+\.txt', f)]

            # 提取文件名中的数字并排序
            sorted_files = sorted(files, key=lambda x: int(re.search(r'-?\d+', x).group()))

            # 第一步：临时重命名所有文件，使用临时前缀避免命名冲突
            temp_prefix = "temp_"
            for file in sorted_files:
                os.rename(os.path.join(save_path, file), os.path.join(save_path, temp_prefix + file))

            # 第二步：从临时命名的文件中按照倒序编号逻辑进行最终重命名
            start_number = 1
            for file in sorted_files:
                new_name = f"{prefix}{start_number}.txt"
                os.rename(os.path.join(save_path, temp_prefix + file), os.path.join(save_path, new_name))
                start_number += 1

        # 分别对L开头和R开头的文件进行重命名
        rename_files(save_path, 'L')
        rename_files(save_path, 'R')


        # 定义一系列的Rib_number
        rib_numbers = ['L' + str(i) for i in range(1, 13)] + ['R' + str(i) for i in range(1, 13)]

        for Rib_number in rib_numbers:
            file_path = f"D:/rib_gui2/runs/detect/Rib/{Rib_number}.txt"  # 确保文件扩展名正确
            print("Checking for file:", file_path)  # 打印路径以确认是否正确
            time.sleep(1)  # 等待1秒钟以减少文件系统延迟的影响

            if not os.path.exists(file_path):
                print("File not found, skipping:", file_path)  # 如果文件不存在，则打印一条消息
                continue

            print("Processing file:", file_path)

        for Rib_number in rib_numbers:
            # 创建渲染器、渲染窗口和交互器
            renX = vtk.vtkRenderer()
            renWin = vtk.vtkRenderWindow()
            renWin.AddRenderer(renX)
            iren = vtk.vtkRenderWindowInteractor()
            iren.SetRenderWindow(renWin)

            # 读取DICOM图像
            v16 = vtk.vtkDICOMImageReader()
            v16.SetDirectoryName(self.folder_path)
            v16.Update()

            reader = sitk.ImageSeriesReader()  # sitk读取dicom图像类
            image_path = reader.GetGDCMSeriesFileNames(self.folder_path)  # 获取文件夹内所有切片路径
            reader.SetFileNames(image_path)  # 通过上面获取到的路径来读取每一张dcm图片
            image = reader.Execute()  # 得到对应的3D图像
            img = image[0]
            min_value = np.min(img)
            spacing = image.GetSpacing()  # 返回一个元组，(像素宽度, 像素高度, 层间距)

            # 设置窗宽和窗位的值
            window_width = 1800
            window_level = -100  # -1000或-100


            # 窗宽窗位调整函数
            def adjust_window_level_width(input_image, level, width):
                windowed_image = vtk.vtkImageMapToWindowLevelColors()
                windowed_image.SetWindow(width)
                windowed_image.SetLevel(level)
                windowed_image.SetInputConnection(input_image.GetOutputPort())
                return windowed_image


            # 应用窗宽窗位调整
            adjusted_image = adjust_window_level_width(v16, window_level, window_width)


            # 计算三点确定平面的法向量（与z轴夹角为锐角）
            def calculate_normal_vector_with_conditions(A, B, C):
                AB = np.array([B[0] - A[0], B[1] - A[1], B[2] - A[2]])
                AC = np.array([C[0] - A[0], C[1] - A[1], C[2] - A[2]])
                normal = np.cross(AB, AC)
                if normal[2] < 0:
                    normal = -normal
                normal_unit = normal / np.linalg.norm(normal)
                return normal_unit.tolist()


            # 打开txt文件，确定三点坐标

            with open('D:/rib_gui2/runs/detect/Rib/' + Rib_number + '.txt', 'r') as file:
                lines = file.readlines()

            # 分别提取每行第二列第三列第四列的值
            txt_values = []

            for line in lines:
                parts = line.split()
                if len(parts) >= 4:
                    txt_values.extend([float(parts[1]), float(parts[2]), float(parts[3])])

            # 计算文件夹中.dcm文件的数量
            dcm_number = sum(1 for file in os.listdir(self.folder_path) if file.endswith('.dcm'))

            # 坐标系转换
            txt_1, txt_2, txt_3, txt_4, txt_5, txt_6, txt_7, txt_8, txt_9 = txt_values[:9]

            A_x = txt_1 * spacing[0]
            A_y = (512 - txt_2) * spacing[1]
            A_z = (dcm_number - txt_3) * spacing[2]
            B_x = txt_4 * spacing[0]
            B_y = (512 - txt_5) * spacing[1]
            B_z = (dcm_number - txt_6) * spacing[2]
            C_x = txt_7 * spacing[0]
            C_y = (512 - txt_8) * spacing[1]
            C_z = (dcm_number - txt_9) * spacing[2]
            A = (A_x, A_y, A_z)
            B = (B_x, B_y, B_z)
            C = (C_x, C_y, C_z)

            def normalize_vector(v):
                norm = np.linalg.norm(v)
                if norm == 0:
                    return v
                return v / norm


            def rotation_matrix_from_vectors(vec1, vec2):
                # Normalize input vectors
                vec1 = normalize_vector(vec1)
                vec2 = normalize_vector(vec2)
                cross_product = np.cross(vec1, vec2)
                dot_product = np.dot(vec1, vec2)
                cross_product_matrix = np.array([[0, -cross_product[2], cross_product[1]],
                                                [cross_product[2], 0, -cross_product[0]],
                                                [-cross_product[1], cross_product[0], 0]])

                # 计算旋转矩阵
                rotation_matrix = np.eye(3) + cross_product_matrix + np.dot(cross_product_matrix, cross_product_matrix) * (
                        1 / (1 + dot_product))

                return rotation_matrix


            # 计算符合条件的法向量
            normal_vector_with_conditions = calculate_normal_vector_with_conditions(A, B, C)

            given_vector = normal_vector_with_conditions
            # 赋值旋转矩阵和平移向量
            rotation_matrix = rotation_matrix_from_vectors([0, 0, 1], given_vector)

            a1 = rotation_matrix[0, 0]
            a2 = rotation_matrix[0, 1]
            a3 = rotation_matrix[0, 2]
            b1 = rotation_matrix[1, 0]
            b2 = rotation_matrix[1, 1]
            b3 = rotation_matrix[1, 2]
            c1 = rotation_matrix[2, 0]
            c2 = rotation_matrix[2, 1]
            c3 = rotation_matrix[2, 2]
            d1 = (A_x + B_x + C_x) / 3
            d2 = (A_y + B_y + C_y) / 3
            d3 = (A_z + B_z + C_z) / 3
            center = [A_x, A_y, A_z]

            # 提取切割平面位置
            resliceAxes = vtk.vtkMatrix4x4()
            resliceAxes.DeepCopy((a1, a2, a3, center[0],
                                b1, b2, b3, center[1],
                                c1, c2, c3, center[2],
                                0, 0, 0, 1))

            # 创建一个PNG写入器
            writer = vtk.vtkPNGWriter()

            # 生成斜平面
            reslice = vtk.vtkImageReslice()
            reslice.SetInputConnection(adjusted_image.GetOutputPort())
            reslice.SetOutputDimensionality(2)
            reslice.SetAutoCropOutput(True)
            reslice.SetResliceAxes(resliceAxes)
            reslice.SetInterpolationModeToLinear()
            # 设置输出图像的大小为512x512
            # 注意：对于SetOutputExtent，参数是[xMin, xMax, yMin, yMax, zMin, zMax]
            reslice.SetOutputExtent(1, 640, 1, 640, 0, 0)

            # 设置背景颜色为黑色，并且设置背景透明度为0（完全不透明）
            reslice.SetBackgroundColor(0.0, 0.0, 0.0, 0.0)  # RGB和Alpha值

            reslice.Update()

            # 将reslice的输出直接连接到PNG写入器
            # folder_path_save = f"E:/detect/"+str(dicom_number)
            folder_path_save ='D:/rib_gui2/save_png'
            if not os.path.exists(folder_path_save):
                os.makedirs(folder_path_save)  # 如果文件夹不存在，则创建文件夹
            output_filename = f"{folder_path_save}/{Rib_number}.png"
            writer.SetFileName(output_filename)  # 指定保存图片的路径和文件名
            writer.SetInputData(reslice.GetOutput())
            writer.Write()
            print(f"Saved {output_filename}")

        self.label_2.setText('图片已导出')

    #鼠标滚轮改变图片大小
    def update_image_scale(self):
        scale_factor = self.slider.value() / 100.0
        pixmap = QPixmap(self.image_path)
        scaled_pixmap = pixmap.scaled(pixmap.width() * scale_factor, pixmap.height() * scale_factor, Qt.KeepAspectRatio)
        self.label_2.setPixmap(scaled_pixmap)

    #显示图片1
    def display_image1(self, image_path):
        self.image_path = image_path
        pixmap = QPixmap(image_path)
        self.label_2.setPixmap(pixmap.scaledToWidth(800))  # 缩放图片以适应标签宽度



    #切换图片
    def update_image(self):
        self.save_path='D:/rib_gui2/save_png'
        if self.save_path:
            selected_item = self.comboBox.currentText()
            image_name1 = f"{selected_item}.png"
            image_path1 = os.path.join(self.save_path, image_name1)
            # image_name2 = f"{selected_item}_2.png"
            if os.path.exists(image_path1):
                self.display_image1(image_path1)
            else:
                print(f"Image '{image_name1}' not found in folder '{self.save_path}'.")
    
    def visiualspace(self):
        selected_item = self.comboBox.currentText()
        renderer, interactor = tangentspace(self.folder_path, selected_item)
        # 这里你可以处理 renderer 或 interactor 的相关操作

    def load_folder(self, folder_path):
        self.total_progress = 0
        self.progressBar.setValue(0)
        self.worker = Worker(folder_path)
        self.worker.progress_changed.connect(self.update_progress)
        self.worker.finished.connect(self.timer.stop)
        self.timer.start(self.timer_interval)

    def update_progress(self):
        if self.total_progress < 100:
            self.total_progress += 1
            self.progressBar.setValue(self.total_progress)
            if self.timer.interval() != self.timer_interval:
                self.timer.setInterval(self.timer_interval)
        else:
            self.timer.stop()

        # Check total time
        if self.timer.isActive():
            if self.timer.interval() * self.total_progress >= self.total_time:
                self.timer.stop()

if __name__=='__main__':
    app=QApplication()
    window=MyWindow()
    # apply_stylesheet(app,theme='light_teal.xml')
    apply_stylesheet(app,theme='light_blue.xml')
    window.show()
    app.exec()