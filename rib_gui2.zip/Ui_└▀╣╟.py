# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file '肋骨.ui'
##
## Created by: Qt User Interface Compiler version 6.6.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QLabel, QProgressBar,
    QPushButton, QSizePolicy, QSlider, QWidget)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1054, 768)
        self.pushButton = QPushButton(Form)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(10, 10, 221, 101))
        font = QFont()
        font.setPointSize(13)
        font.setBold(True)
        self.pushButton.setFont(font)
        self.label = QLabel(Form)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(310, 50, 91, 31))
        font1 = QFont()
        font1.setFamilies([u"Microsoft YaHei UI"])
        font1.setPointSize(12)
        font1.setBold(True)
        self.label.setFont(font1)
        self.comboBox = QComboBox(Form)
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setGeometry(QRect(420, 60, 341, 22))
        self.label_2 = QLabel(Form)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(70, 240, 801, 481))
        self.slider = QSlider(Form)
        self.slider.setObjectName(u"slider")
        self.slider.setGeometry(QRect(420, 120, 221, 21))
        self.slider.setOrientation(Qt.Horizontal)
        self.pushButton_2 = QPushButton(Form)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(10, 120, 221, 71))
        font2 = QFont()
        font2.setPointSize(13)
        font2.setBold(True)
        font2.setItalic(False)
        self.pushButton_2.setFont(font2)
        self.label_3 = QLabel(Form)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(270, 110, 141, 41))
        font3 = QFont()
        font3.setPointSize(12)
        font3.setBold(True)
        self.label_3.setFont(font3)
        self.label_4 = QLabel(Form)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(760, 0, 291, 231))
        self.progressBar = QProgressBar(Form)
        self.progressBar.setObjectName(u"progressBar")
        self.progressBar.setGeometry(QRect(70, 730, 811, 20))
        self.progressBar.setValue(0)
        self.progressBar.setTextVisible(True)
        self.label_5 = QLabel(Form)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(0, 0, 1061, 771))
        self.label_5.raise_()
        self.label_2.raise_()
        self.pushButton.raise_()
        self.label.raise_()
        self.comboBox.raise_()
        self.slider.raise_()
        self.pushButton_2.raise_()
        self.label_3.raise_()
        self.progressBar.raise_()
        self.label_4.raise_()

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.pushButton.setText(QCoreApplication.translate("Form", u"\u6253\u5f00\u6587\u4ef6\u5939", None))
        self.label.setText(QCoreApplication.translate("Form", u"  \u7c7b\u522b", None))
        self.label_2.setText(QCoreApplication.translate("Form", u"\u56fe\u7247\u663e\u793a\u754c\u9762", None))
        self.pushButton_2.setText(QCoreApplication.translate("Form", u"\u89c6\u56fe\u8c03\u8282", None))
        self.label_3.setText(QCoreApplication.translate("Form", u" \u56fe\u7247\u7f29\u653e\u5668", None))
        self.label_4.setText(QCoreApplication.translate("Form", u"TextLabel", None))
        self.label_5.setText(QCoreApplication.translate("Form", u"TextLabel", None))
    # retranslateUi

